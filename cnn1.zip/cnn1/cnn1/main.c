#include <stdio.h>
#include <stdlib.h>
#include <math.h>
void matrix_multi(unsigned char r1,unsigned char c1, unsigned char r2, unsigned char c2,float *a,float *b,float *c,float *bias)
{
    float sum=0;
    unsigned char i=0,j=0,m=0;
    for (i=0;i<r1;i++)
    {
        for (j=0;j<c2;j++)
        {
            sum=0;
            for (m=0;m<r2;m++)
            {
                sum = sum+a[i*r2+m]*b[m*c2+j];
            }
            c[i*r2+j] = sum+bias[j];
        }
    }
}
float multi(unsigned char len,float *filter,float *input)
{
    unsigned char i=0;
    float sum=0;
    for (i=0;i<len;i++)
    {
        sum = sum+filter[i]*input[i];
    }
    return sum;
}
void conv1(unsigned char input_len,unsigned char filter_len,float *input,float *filter,float *output,float bias)
{
    unsigned char i=0;
    unsigned char j=0;
    float tmp[5]={0};
    for (i=0;i<input_len-filter_len+1;i++)
    {
        for (j=0;j<filter_len;j++)
        {
            tmp[j]=input[j+i];
        }
        output[i] = multi(filter_len,filter,tmp)+bias;
    }
}
void relu(float *input,unsigned char row,unsigned char col)
{
    unsigned char i=0;
    unsigned char j=0;
    for (i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
            if (input[i*col+j]<0)
            input[i*col+j]=0;
        }
    }
}
void flatten(float *input1,float *input2,unsigned char len,float *output)
{
    unsigned char i=0;
    for (i=0;i<len;i++)
    {
        output[2*i] = input1[i];
        output[2*i+1] = input2[i];
    }
}
int main()
{
    float result=0;
    float input[9] = {0.3888889,1,0,1,0,0,2,3,5};
    float filter1[5] = {0.049175248,0.7807992,0.5829576,0.56396663,-0.24123521};
    float filter2[5] = {0.21567109,0.10410377,0.23594074,0.31501943,-0.832668};
    float bias1[2] ={-0.0014241252,0.18483366};
    float output11[5]={0};
    float output12[5]={0};
    float output2[10]={0};
    float filter3[10][8]={-0.0035906613,0.02454063,	0.22369815,	-0.38220695,0.30651575,	-0.14400837,-0.045424715,0.23935907,
                        0.040118366,	-0.14687337,	-0.3081812,	-0.28150338,	-0.11539744,	-0.1364027,	-0.37770846,-0.05404371,
                        0.41706592,	-0.21911718,	-0.2285368,	-0.086340755,	-0.5032607,	0.5030032,	-0.51970667,-0.5589298,
                        -0.13076822,	0.2371957,	-0.43628225,	0.018323623,	-0.27133977,	0.23529111,	0.28638357,0.4738312,
                        0.38099995,	-0.47251585,	-0.28723094	,-0.6691202,	-0.24959326,	0.18183203,	-0.5201807,0.25861254,
                        0.053268656,	-0.4784158,	0.018145801	,0.28657952,	-0.22817361,	0.060912386,	0.3074651,-0.33357835,
                        -0.33059335,	-0.2111527	,0.043590352,	-0.36948544,	-0.38445157,	0.2958451,	-0.08996585,0.16134025,
                        -0.117133714,	-0.072916426,	0.23793738,	-0.2322069,	0.15959376,	-0.71243376,	-0.013374559,0.9162724,
                        0.32397005,	0.5340016,	0.077539235,	0.524266,	-0.4227745,	0.39461353,	0.31911156,-0.19284411,
                        0.12564807,	0.56047595,	-0.22971112,	0.18385468,	0.036971807,	0.2793356,	-0.027010262,0.45817685};
    float bias2[8]={0.10975222,-1.4093122E-4,0.054997325,-0.06646814,0.005095516,0.018398402,-0.22408605,0.24853046};
    float output3[8]={0};
    float filter4[8][8]={0.2815521,	-0.43305296,	0.05937551,	-0.30307588,	-0.026063293,	0.44534233,	0.12914905,	0.34981936,
    -0.09752105,	0.21829201,	0.26729953,	0.19718216,	-0.45510742,	-8.8249356E-4,	-0.53893626,	-0.25664246,
    0.2000916,	-0.0924242	,-0.33305344,	0.711288,	0.6115244,	-0.26097718,	-0.23805231,	0.5869799,
    -0.35458514,	-0.3348051,	0.2964315,	0.5198223,	-0.21060409,	-0.13673753,	-0.47676516,	0.29301742,
    -0.36560893	,-0.45916843,	0.4733793,	-0.23116629,	0.46929714,	0.60895365,	-0.33660743,	0.47025254,
    -0.41044623	,-0.35294577,	0.6755438,	-0.5087271,	0.5082949,	0.4665358,	-0.16061616,	0.14786239,
    0.20243238	,0.038596965,	0.2171348,	0.017599022,	0.13296343,	-0.28839177,	-0.14860868,	-0.3213552,
    0.0019146579,	0.8628312,	-0.30240107,	0.9137539,	-0.3240369	,-0.29500037,	0.047384836,	-0.066662945};
    float bias3[8]={-0.11891515,0.37363845,0.032949526,0.35437644,0.06322167,0.119072765,-0.11859716,-0.13824527};
    float output4[8]={0};
    float filter5[8][1]={0.10116522,
                    -0.63007426,
                    0.22905579,
                    -0.90953773,
                    0.9206526,
                    0.7723042,
                    0.32016927,
                    0.34818286};
    float bias4[1]={-0.23349635};
    float output5[1]={0};
    conv1(9,5,input,filter1,output11,bias1[0]);
    conv1(9,5,input,filter2,output12,bias1[1]);
    relu(output11,1,5);
    relu(output12,1,5);
    flatten(output11,output12,5,output2);
    matrix_multi(1,10,10,8,output2,*filter3,output3,bias2);
    relu(output3,1,8);
    matrix_multi(1,8,8,8,output3,*filter4,output4,bias3);
    relu(output4,1,8);
    matrix_multi(1,8,8,1,output4,*filter5,output5,bias4);
    result = 1/(1+exp(-output5[0]));
    if (result>0.5)
        result = 1;
    else
        result = 0;
    //printf("%.*f",8,result);
}
